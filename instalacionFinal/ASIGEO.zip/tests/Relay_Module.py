##################################################

#           P26 ----> Relay_Ch1
#			P20 ----> Relay_Ch2
#			P21 ----> Relay_Ch3

##################################################
# !/usr/bin/python
# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
import time


class Relees:

    def relayon(self, ch):
        relee = self.Relays[ch - 1]
        GPIO.output(relee, GPIO.HIGH)
        print('Enciendo rele ' + str(ch))

    def relayoff(self, ch):
        relee = self.Relays[ch - 1]
        GPIO.output(relee, GPIO.LOW)
        print('Apago rele ' + str(ch))

    def abrir_bomba(self, zona):
        r = zona * 3
        self.relayon(r)

    def cerrar_bomba(self, zona):
        r = zona * 3
        self.relayoff(r)

    def abrir_bomba_dir(self, zona):
        r = zona + 8 # La zona 5 que es la primera zona directa es el rele 13
        self.relayon(r)

    def cerrar_bomba_dir(self, zona):
        r = zona + 8 # La zona 5 que es la primera zona directa es el rele 13
        self.relayoff(r)

    def abrir_zona(self, zona):
        r1 = 3 * (zona - 1) + 1
        r2 = 3 * (zona - 1) + 2
        self.relayoff(r2)
        self.relayon(r1)

    def cerrar_zona(self, zona):
        r1 = 3 * (zona - 1) + 1
        r2 = 3 * (zona - 1) + 2
        self.relayoff(r1)
        self.relayon(r2)

    def parar_zona(self, zona):
        r1 = 3 * (zona - 1) + 1
        r2 = 3 * (zona - 1) + 2
        self.relayoff(r1)
        self.relayoff(r2)

    def seguridad(self):
        GPIO.output(self.Relay_Ch1, GPIO.LOW)
        GPIO.output(self.Relay_Ch2, GPIO.HIGH)
        GPIO.output(self.Relay_Ch3, GPIO.LOW)
        GPIO.output(self.Relay_Ch4, GPIO.LOW)
        GPIO.output(self.Relay_Ch5, GPIO.HIGH)
        GPIO.output(self.Relay_Ch6, GPIO.LOW)
        GPIO.output(self.Relay_Ch7, GPIO.LOW)
        GPIO.output(self.Relay_Ch8, GPIO.LOW)

    def __init__(self):
        # Zona 1
        self.Relay_Ch1 = 12
        self.Relay_Ch2 = 5
        self.Relay_Ch3 = 2
        # Zona 2
        self.Relay_Ch4 = 25
        self.Relay_Ch5 = 24
        self.Relay_Ch6 = 3
        # Zona 3
        self.Relay_Ch7 = 22
        self.Relay_Ch8 = 23
        self.Relay_Ch9 = 14
        # Zona 4
        self.Relay_Ch10 = 27
        self.Relay_Ch11 = 17
        self.Relay_Ch12 = 4
        # Zonas directas 5 y 6
        self.Relay_Ch13 = 15
        self.Relay_Ch14 = 18

        self.Relays = [self.Relay_Ch1, self.Relay_Ch2, self.Relay_Ch3, self.Relay_Ch4, self.Relay_Ch5, self.Relay_Ch6,
                       self.Relay_Ch7, self.Relay_Ch8, self.Relay_Ch9, self.Relay_Ch10, self.Relay_Ch11, self.Relay_Ch12,
                       self.Relay_Ch13, self.Relay_Ch14]

        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BCM)
        for rele in self.Relays:
            GPIO.setup(rele, GPIO.OUT)

        for rele in self.Relays:
            GPIO.output(rele, GPIO.LOW)

    def test(self):
        try:
            while True:
                for i in range(16):

                    GPIO.output(self.Relays[i], GPIO.HIGH)
                    print("Channel " + str(i) + ":Abriendo!\n")
                    time.sleep(0.5)

                    GPIO.output(self.Relays[i], GPIO.LOW)
                    print("Channel " + str(i) + ":Cerrando!\n")
                    time.sleep(0.5)
        except:
            print("except")
            GPIO.cleanup()

    def testzona(self,zona):
        while True:
            i = 3
            rel.abrir_zona(i)
            time.sleep(2)
            rel.cerrar_zona(i)
            time.sleep(2)
            rel.abrir_bomba(i)
            time.sleep(2)
            rel.cerrar_bomba(i)
            time.sleep(2)

    def testzonadir(self,zona):
        while True:
            rel.abrir_bomba_dir(zona)
            time.sleep(2)
            rel.cerrar_bomba_dir(zona)
            time.sleep(2)







if __name__ == '__main__':
    rel = Relees()
    rel.testzonadir(6)



