from MCP3208 import MCP3208
import time

CLK = 11
MISO = 9
MOSI = 10
CS = [8, 7]

mcp = MCP3208(clk=CLK, cs=CS[0], miso=MISO, mosi=MOSI)
mcp2 = MCP3208(clk=CLK, cs=CS[1], miso=MISO, mosi=MOSI)
adc = [mcp, mcp2]


if __name__ == '__main__':
    for j in range(0, 2):
        for i in range(0, 8):
            lev = adc[j].read(i)
            print("Leyendo adc" + str(j) + ", canal" + str(i))
            print(lev)
            time.sleep(1)